module.exports = {
    mysql: {
        host: 'localhost',
        user: 'root',
        password: 'LIlong5490624',
        database: 'lexuemao',
        charset: 'utf8',
        port: 3306
    }
}

/*
 Navicat Premium Data Transfer

 Source Server         : localhost
 Source Server Type    : MySQL
 Source Server Version : 80015
 Source Host           : localhost:3306
 Source Schema         : lexuemao

 Target Server Type    : MySQL
 Target Server Version : 80015
 File Encoding         : 65001

 Date: 06/12/2019 15:40:52
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for lxm_file_dir
-- ----------------------------
DROP TABLE IF EXISTS `lxm_file_dir`;
CREATE TABLE `lxm_file_dir` (
  `dir_id` int(10) NOT NULL AUTO_INCREMENT,
  `dir_pid` int(10) NOT NULL DEFAULT '0',
  `dir_name` varchar(255) NOT NULL,
  `dir_path` varchar(1000) NOT NULL,
  `uniq` varchar(36) NOT NULL,
  `depth` int(2) NOT NULL,
  `is_share` int(1) NOT NULL DEFAULT '0',
  `create_uid` varchar(36) NOT NULL,
  `create_time` datetime NOT NULL,
  `update_uid` varchar(36) DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `delete_uid` varchar(36) DEFAULT NULL,
  `delete_time` datetime DEFAULT NULL,
  `is_delete` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`dir_id`,`uniq`,`dir_name`) USING BTREE,
  UNIQUE KEY `uniq` (`uniq`),
  UNIQUE KEY `dir_path` (`dir_path`,`is_delete`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=329 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of lxm_file_dir
-- ----------------------------
BEGIN;
INSERT INTO `lxm_file_dir` VALUES (271, 0, '总部', '/Users/lilong/Documents/中科思远/lxm-files/files/staff/总部', 'ba5988f0-09d7-11ea-892a-771d6ae3ac75', 8, 0, '85643570-05e8-11ea-b251-bf127ba383f1', '2019-11-18 15:47:53', NULL, NULL, NULL, NULL, 0);
INSERT INTO `lxm_file_dir` VALUES (272, 271, '总部共享', '/Users/lilong/Documents/中科思远/lxm-files/files/staff/总部/总部共享', 'ba59d710-09d7-11ea-892a-771d6ae3ac75', 9, 1, '85643570-05e8-11ea-b251-bf127ba383f1', '2019-11-18 15:47:53', NULL, NULL, NULL, NULL, 0);
INSERT INTO `lxm_file_dir` VALUES (273, 0, '学校', '/Users/lilong/Documents/中科思远/lxm-files/files/staff/学校', 'e8c9f670-09d7-11ea-bb09-25e0842be5de', 8, 0, '85643570-05e8-11ea-b251-bf127ba383f1', '2019-11-18 15:49:11', NULL, NULL, NULL, NULL, 0);
INSERT INTO `lxm_file_dir` VALUES (274, 273, '学校共享', '/Users/lilong/Documents/中科思远/lxm-files/files/staff/学校/学校共享', 'e8ca4490-09d7-11ea-bb09-25e0842be5de', 9, 1, '85643570-05e8-11ea-b251-bf127ba383f1', '2019-11-18 15:49:11', NULL, NULL, NULL, NULL, 0);
INSERT INTO `lxm_file_dir` VALUES (277, 271, '技术部', '/Users/lilong/Documents/中科思远/lxm-files/files/staff/总部/技术部', '0c4780e0-09d8-11ea-be3d-f3574d26d6bd', 9, 0, '85643570-05e8-11ea-b251-bf127ba383f1', '2019-11-18 15:50:11', NULL, NULL, NULL, NULL, 0);
INSERT INTO `lxm_file_dir` VALUES (278, 277, '技术部共享', '/Users/lilong/Documents/中科思远/lxm-files/files/staff/总部/技术部/技术部共享', '0c47cf00-09d8-11ea-be3d-f3574d26d6bd', 10, 1, '85643570-05e8-11ea-b251-bf127ba383f1', '2019-11-18 15:50:11', NULL, NULL, NULL, NULL, 0);
INSERT INTO `lxm_file_dir` VALUES (279, 271, '销售部', '/Users/lilong/Documents/中科思远/lxm-files/files/staff/总部/销售部', '119450a0-09d8-11ea-a2f8-d9ece6d40dba', 9, 0, '85643570-05e8-11ea-b251-bf127ba383f1', '2019-11-18 15:50:20', NULL, NULL, NULL, NULL, 0);
INSERT INTO `lxm_file_dir` VALUES (280, 279, '销售部共享', '/Users/lilong/Documents/中科思远/lxm-files/files/staff/总部/销售部/销售部共享', '11949ec0-09d8-11ea-a2f8-d9ece6d40dba', 10, 1, '85643570-05e8-11ea-b251-bf127ba383f1', '2019-11-18 15:50:20', NULL, NULL, NULL, NULL, 0);
INSERT INTO `lxm_file_dir` VALUES (281, 271, '总经理岗', '/Users/lilong/Documents/中科思远/lxm-files/files/staff/总部/总经理岗', '29abeae0-09d8-11ea-97bf-33b41ab5fd52', 9, 0, '85643570-05e8-11ea-b251-bf127ba383f1', '2019-11-18 15:51:00', NULL, NULL, NULL, NULL, 0);
INSERT INTO `lxm_file_dir` VALUES (282, 281, '总经理岗共享', '/Users/lilong/Documents/中科思远/lxm-files/files/staff/总部/总经理岗/总经理岗共享', '29ac11f0-09d8-11ea-97bf-33b41ab5fd52', 10, 1, '85643570-05e8-11ea-b251-bf127ba383f1', '2019-11-18 15:51:00', NULL, NULL, NULL, NULL, 0);
INSERT INTO `lxm_file_dir` VALUES (283, 277, '技术经理岗', '/Users/lilong/Documents/中科思远/lxm-files/files/staff/总部/技术部/技术经理岗', '301c2c00-09d8-11ea-83eb-8952fa23e46c', 10, 0, '85643570-05e8-11ea-b251-bf127ba383f1', '2019-11-18 15:51:11', NULL, NULL, NULL, NULL, 0);
INSERT INTO `lxm_file_dir` VALUES (284, 283, '技术经理岗共享', '/Users/lilong/Documents/中科思远/lxm-files/files/staff/总部/技术部/技术经理岗/技术经理岗共享', '301c5310-09d8-11ea-83eb-8952fa23e46c', 11, 1, '85643570-05e8-11ea-b251-bf127ba383f1', '2019-11-18 15:51:11', NULL, NULL, NULL, NULL, 0);
INSERT INTO `lxm_file_dir` VALUES (285, 277, '前端岗', '/Users/lilong/Documents/中科思远/lxm-files/files/staff/总部/技术部/前端岗', '34b22ee0-09d8-11ea-b1fe-d17b28d97707', 10, 0, '85643570-05e8-11ea-b251-bf127ba383f1', '2019-11-18 15:51:18', NULL, NULL, NULL, NULL, 0);
INSERT INTO `lxm_file_dir` VALUES (286, 285, '前端岗共享', '/Users/lilong/Documents/中科思远/lxm-files/files/staff/总部/技术部/前端岗/前端岗共享', '34b255f0-09d8-11ea-b1fe-d17b28d97707', 11, 1, '85643570-05e8-11ea-b251-bf127ba383f1', '2019-11-18 15:51:18', NULL, NULL, NULL, NULL, 0);
INSERT INTO `lxm_file_dir` VALUES (287, 277, '后端岗', '/Users/lilong/Documents/中科思远/lxm-files/files/staff/总部/技术部/后端岗', '370a76c0-09d8-11ea-a9a1-abf23ff13382', 10, 0, '85643570-05e8-11ea-b251-bf127ba383f1', '2019-11-18 15:51:22', NULL, NULL, NULL, NULL, 0);
INSERT INTO `lxm_file_dir` VALUES (288, 287, '后端岗共享', '/Users/lilong/Documents/中科思远/lxm-files/files/staff/总部/技术部/后端岗/后端岗共享', '370a9dd0-09d8-11ea-a9a1-abf23ff13382', 11, 1, '85643570-05e8-11ea-b251-bf127ba383f1', '2019-11-18 15:51:22', NULL, NULL, NULL, NULL, 0);
INSERT INTO `lxm_file_dir` VALUES (289, 279, '销售经理岗', '/Users/lilong/Documents/中科思远/lxm-files/files/staff/总部/销售部/销售经理岗', '3f4342e0-09d8-11ea-a554-51cf7353d220', 10, 0, '85643570-05e8-11ea-b251-bf127ba383f1', '2019-11-18 15:51:36', NULL, NULL, NULL, NULL, 0);
INSERT INTO `lxm_file_dir` VALUES (290, 289, '销售经理岗共享', '/Users/lilong/Documents/中科思远/lxm-files/files/staff/总部/销售部/销售经理岗/销售经理岗共享', '3f439100-09d8-11ea-a554-51cf7353d220', 11, 1, '85643570-05e8-11ea-b251-bf127ba383f1', '2019-11-18 15:51:36', NULL, NULL, NULL, NULL, 0);
INSERT INTO `lxm_file_dir` VALUES (291, 279, '售前岗', '/Users/lilong/Documents/中科思远/lxm-files/files/staff/总部/销售部/售前岗', '454a13d0-09d8-11ea-93eb-0faf8f34f021', 10, 0, '85643570-05e8-11ea-b251-bf127ba383f1', '2019-11-18 15:51:46', NULL, NULL, NULL, NULL, 0);
INSERT INTO `lxm_file_dir` VALUES (292, 291, '售前岗共享', '/Users/lilong/Documents/中科思远/lxm-files/files/staff/总部/销售部/售前岗/售前岗共享', '454a3ae0-09d8-11ea-93eb-0faf8f34f021', 11, 1, '85643570-05e8-11ea-b251-bf127ba383f1', '2019-11-18 15:51:46', NULL, NULL, NULL, NULL, 0);
INSERT INTO `lxm_file_dir` VALUES (293, 279, '售后岗', '/Users/lilong/Documents/中科思远/lxm-files/files/staff/总部/销售部/售后岗', '491a2ea0-09d8-11ea-a818-7351d9c2812a', 10, 0, '85643570-05e8-11ea-b251-bf127ba383f1', '2019-11-18 15:51:53', NULL, NULL, NULL, NULL, 0);
INSERT INTO `lxm_file_dir` VALUES (294, 293, '售后岗共享', '/Users/lilong/Documents/中科思远/lxm-files/files/staff/总部/销售部/售后岗/售后岗共享', '491a55b0-09d8-11ea-a818-7351d9c2812a', 11, 1, '85643570-05e8-11ea-b251-bf127ba383f1', '2019-11-18 15:51:53', NULL, NULL, NULL, NULL, 0);
INSERT INTO `lxm_file_dir` VALUES (295, 281, 'zhouping', '/Users/lilong/Documents/中科思远/lxm-files/files/staff/总部/总经理岗/zhouping', 'b0148a60-09dd-11ea-a6e4-b7d561e1d6d4', 10, 0, '8e2cbb20-09dd-11ea-a6e4-b7d561e1d6d4', '2019-11-18 16:30:33', NULL, NULL, NULL, NULL, 0);
INSERT INTO `lxm_file_dir` VALUES (296, 283, 'litingqiang', '/Users/lilong/Documents/中科思远/lxm-files/files/staff/总部/技术部/技术经理岗/litingqiang', '7aa1c300-09df-11ea-9bfc-7d0d6041a49e', 11, 0, '8e2cbb20-09dd-11ea-a6e4-b7d561e1d6d4', '2019-11-18 16:43:22', NULL, NULL, NULL, NULL, 0);
INSERT INTO `lxm_file_dir` VALUES (297, 285, 'lilong', '/Users/lilong/Documents/中科思远/lxm-files/files/staff/总部/技术部/前端岗/lilong', '844801d0-09df-11ea-9027-b1ebe771fddd', 11, 0, '8e2cbb20-09dd-11ea-a6e4-b7d561e1d6d4', '2019-11-18 16:43:38', NULL, NULL, NULL, NULL, 0);
INSERT INTO `lxm_file_dir` VALUES (298, 287, 'liuweiming', '/Users/lilong/Documents/中科思远/lxm-files/files/staff/总部/技术部/后端岗/liuweiming', '8f30abb0-09df-11ea-8989-8b09e81ea253', 11, 0, '8e2cbb20-09dd-11ea-a6e4-b7d561e1d6d4', '2019-11-18 16:43:57', NULL, NULL, NULL, NULL, 0);
INSERT INTO `lxm_file_dir` VALUES (299, 289, 'zhouyuan', '/Users/lilong/Documents/中科思远/lxm-files/files/staff/总部/销售部/销售经理岗/zhouyuan', 'f6045ee0-09df-11ea-822c-03ae4be5ecb3', 11, 0, '8e2cbb20-09dd-11ea-a6e4-b7d561e1d6d4', '2019-11-18 16:46:49', NULL, NULL, NULL, NULL, 0);
INSERT INTO `lxm_file_dir` VALUES (300, 291, 'panpeng', '/Users/lilong/Documents/中科思远/lxm-files/files/staff/总部/销售部/售前岗/panpeng', '03d115e0-09e0-11ea-85c4-17bb4b079cf8', 11, 0, '8e2cbb20-09dd-11ea-a6e4-b7d561e1d6d4', '2019-11-18 16:47:12', NULL, NULL, NULL, NULL, 0);
INSERT INTO `lxm_file_dir` VALUES (301, 293, 'tangwen', '/Users/lilong/Documents/中科思远/lxm-files/files/staff/总部/销售部/售后岗/tangwen', '0f9bbb50-09e0-11ea-b6fd-57a9a9a40913', 11, 0, '8e2cbb20-09dd-11ea-a6e4-b7d561e1d6d4', '2019-11-18 16:47:32', NULL, NULL, NULL, NULL, 0);
INSERT INTO `lxm_file_dir` VALUES (302, 297, '开发文档', '/Users/lilong/Documents/中科思远/lxm-files/files/staff/总部/技术部/前端岗/lilong/开发文档', '326b5280-09e0-11ea-972a-1b227269f6bc', 12, 0, '8e2cbb20-09dd-11ea-a6e4-b7d561e1d6d4', '2019-11-18 16:48:31', NULL, NULL, '843dc8a0-09df-11ea-9027-b1ebe771fddd', '2019-11-19 11:42:39', 0);
INSERT INTO `lxm_file_dir` VALUES (303, 297, '开发资料', '/Users/lilong/Documents/中科思远/lxm-files/files/staff/总部/技术部/前端岗/lilong/开发资料', '45f77130-09e0-11ea-afc6-fb2eb1dc217e', 12, 0, '8e2cbb20-09dd-11ea-a6e4-b7d561e1d6d4', '2019-11-18 16:49:03', NULL, NULL, NULL, NULL, 0);
INSERT INTO `lxm_file_dir` VALUES (304, 297, '参考资料', '/Users/lilong/Documents/中科思远/lxm-files/files/staff/总部/技术部/前端岗/lilong/参考资料', '4addde00-09e0-11ea-9278-938ceee3e248', 12, 0, '8e2cbb20-09dd-11ea-a6e4-b7d561e1d6d4', '2019-11-18 16:49:12', NULL, NULL, NULL, NULL, 0);
INSERT INTO `lxm_file_dir` VALUES (305, 302, '基础版', '/Users/lilong/Documents/中科思远/lxm-files/files/staff/总部/技术部/前端岗/lilong/开发文档/基础版', '73511780-09e0-11ea-b5c5-53c8afc93b36', 13, 0, '843dc8a0-09df-11ea-9027-b1ebe771fddd', '2019-11-18 16:50:20', NULL, NULL, '843dc8a0-09df-11ea-9027-b1ebe771fddd', '2019-11-19 11:42:39', 0);
INSERT INTO `lxm_file_dir` VALUES (306, 302, 'AI版', '/Users/lilong/Documents/中科思远/lxm-files/files/staff/总部/技术部/前端岗/lilong/开发文档/AI版', '77283730-09e0-11ea-9748-0f36cd0b6aef', 13, 0, '843dc8a0-09df-11ea-9027-b1ebe771fddd', '2019-11-18 16:50:26', NULL, NULL, '843dc8a0-09df-11ea-9027-b1ebe771fddd', '2019-11-19 11:42:39', 0);
INSERT INTO `lxm_file_dir` VALUES (307, 302, '官网', '/Users/lilong/Documents/中科思远/lxm-files/files/staff/总部/技术部/前端岗/lilong/开发文档/官网', '7c515250-09e0-11ea-8117-bdd67774e637', 13, 0, '843dc8a0-09df-11ea-9027-b1ebe771fddd', '2019-11-18 16:50:35', NULL, NULL, '843dc8a0-09df-11ea-9027-b1ebe771fddd', '2019-11-19 11:42:39', 0);
INSERT INTO `lxm_file_dir` VALUES (308, 296, '管理经验', '/Users/lilong/Documents/中科思远/lxm-files/files/staff/总部/技术部/技术经理岗/litingqiang/管理经验', 'ba86eca0-09fa-11ea-9045-0d7514029a3b', 12, 0, '8e2cbb20-09dd-11ea-a6e4-b7d561e1d6d4', '2019-11-18 19:58:26', NULL, NULL, NULL, NULL, 0);
INSERT INTO `lxm_file_dir` VALUES (315, 277, '设计岗', '/Users/lilong/Documents/中科思远/lxm-files/files/staff/总部/技术部/设计岗', '7b1e6e00-0a98-11ea-be78-8d1259df24c4', 10, 0, '8e2cbb20-09dd-11ea-a6e4-b7d561e1d6d4', '2019-11-19 14:47:40', NULL, NULL, NULL, NULL, 0);
INSERT INTO `lxm_file_dir` VALUES (316, 315, '设计岗共享', '/Users/lilong/Documents/中科思远/lxm-files/files/staff/总部/技术部/设计岗/设计岗共享', '7b1e9510-0a98-11ea-be78-8d1259df24c4', 11, 1, '8e2cbb20-09dd-11ea-a6e4-b7d561e1d6d4', '2019-11-19 14:47:40', NULL, NULL, NULL, NULL, 0);
INSERT INTO `lxm_file_dir` VALUES (317, 315, 'ouyang', '/Users/lilong/Documents/中科思远/lxm-files/files/staff/总部/技术部/设计岗/ouyang', '52b77410-0a99-11ea-9081-df2084ad8b05', 11, 0, '8e2cbb20-09dd-11ea-a6e4-b7d561e1d6d4', '2019-11-19 14:53:42', NULL, NULL, NULL, NULL, 0);
INSERT INTO `lxm_file_dir` VALUES (318, 317, '重回设计资料', '/Users/lilong/Documents/中科思远/lxm-files/files/staff/总部/技术部/设计岗/ouyang/重回设计资料', '7770d9e0-0a99-11ea-a5dd-2f57f6ef7128', 12, 0, '52adfe30-0a99-11ea-9081-df2084ad8b05', '2019-11-19 14:54:43', '52adfe30-0a99-11ea-9081-df2084ad8b05', '2019-11-19 16:26:54', '52adfe30-0a99-11ea-9081-df2084ad8b05', '2019-11-19 16:09:43', 0);
INSERT INTO `lxm_file_dir` VALUES (319, 317, '设计文档', '/Users/lilong/Documents/中科思远/lxm-files/files/staff/总部/技术部/设计岗/ouyang/设计文档', '10b92840-0a9b-11ea-b358-4b3588551b92', 12, 0, '52adfe30-0a99-11ea-9081-df2084ad8b05', '2019-11-19 15:06:10', '52adfe30-0a99-11ea-9081-df2084ad8b05', '2019-11-19 16:18:01', '52adfe30-0a99-11ea-9081-df2084ad8b05', '2019-11-19 16:08:40', 0);
INSERT INTO `lxm_file_dir` VALUES (320, 315, 'chengyuxi', '/Users/lilong/Documents/中科思远/lxm-files/files/staff/总部/技术部/设计岗/chengyuxi', '3953bab0-0aad-11ea-b804-41c5346fba10', 11, 0, '52adfe30-0a99-11ea-9081-df2084ad8b05', '2019-11-19 17:16:09', NULL, NULL, NULL, NULL, 0);
INSERT INTO `lxm_file_dir` VALUES (321, 273, '校区A', '/Users/lilong/Documents/中科思远/lxm-files/files/staff/学校/校区A', 'ceca5a70-0ffa-11ea-bd5f-df100be50d39', 9, 0, '843dc8a0-09df-11ea-9027-b1ebe771fddd', '2019-11-26 11:14:07', NULL, NULL, NULL, NULL, 0);
INSERT INTO `lxm_file_dir` VALUES (322, 321, '校区A共享', '/Users/lilong/Documents/中科思远/lxm-files/files/staff/学校/校区A/校区A共享', 'cecacfa0-0ffa-11ea-bd5f-df100be50d39', 10, 1, '843dc8a0-09df-11ea-9027-b1ebe771fddd', '2019-11-26 11:14:07', NULL, NULL, NULL, NULL, 0);
INSERT INTO `lxm_file_dir` VALUES (323, 321, '校长岗', '/Users/lilong/Documents/中科思远/lxm-files/files/staff/学校/校区A/校长岗', '2c0e7930-0ffd-11ea-ad5f-2d46bb2f68ff', 10, 0, '843dc8a0-09df-11ea-9027-b1ebe771fddd', '2019-11-26 11:31:02', NULL, NULL, NULL, NULL, 0);
INSERT INTO `lxm_file_dir` VALUES (324, 323, '校长岗共享', '/Users/lilong/Documents/中科思远/lxm-files/files/staff/学校/校区A/校长岗/校长岗共享', '2c0ea040-0ffd-11ea-ad5f-2d46bb2f68ff', 11, 1, '843dc8a0-09df-11ea-9027-b1ebe771fddd', '2019-11-26 11:31:02', NULL, NULL, NULL, NULL, 0);
INSERT INTO `lxm_file_dir` VALUES (325, 321, '副校长岗', '/Users/lilong/Documents/中科思远/lxm-files/files/staff/学校/校区A/副校长岗', '6213f4b0-10ed-11ea-b262-5975ad0cce87', 10, 0, '843dc8a0-09df-11ea-9027-b1ebe771fddd', '2019-11-27 16:10:32', NULL, NULL, NULL, NULL, 0);
INSERT INTO `lxm_file_dir` VALUES (326, 325, '副校长岗共享', '/Users/lilong/Documents/中科思远/lxm-files/files/staff/学校/校区A/副校长岗/副校长岗共享', '621469e0-10ed-11ea-b262-5975ad0cce87', 11, 1, '843dc8a0-09df-11ea-9027-b1ebe771fddd', '2019-11-27 16:10:32', NULL, NULL, NULL, NULL, 0);
INSERT INTO `lxm_file_dir` VALUES (327, 325, 'mengran', '/Users/lilong/Documents/中科思远/lxm-files/files/staff/学校/校区A/副校长岗/mengran', '93159ac0-10f5-11ea-be6e-0b7972178198', 11, 0, '52adfe30-0a99-11ea-9081-df2084ad8b05', '2019-11-27 17:09:10', NULL, NULL, NULL, NULL, 0);
INSERT INTO `lxm_file_dir` VALUES (328, 319, '新建目录', '/Users/lilong/Documents/中科思远/lxm-files/files/staff/总部/技术部/设计岗/ouyang/设计文档/新建目录', '58c13320-173a-11ea-b6d7-1bb93020dbf8', 13, 0, '52adfe30-0a99-11ea-9081-df2084ad8b05', '2019-12-05 16:36:35', NULL, NULL, NULL, NULL, 0);
COMMIT;

-- ----------------------------
-- Table structure for lxm_file_file
-- ----------------------------
DROP TABLE IF EXISTS `lxm_file_file`;
CREATE TABLE `lxm_file_file` (
  `file_id` int(10) NOT NULL AUTO_INCREMENT,
  `dir_id` int(10) NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `file_path` varchar(1000) NOT NULL,
  `type` int(2) NOT NULL COMMENT '1：文档、2：图片、3：音频、4：视频',
  `ext` varchar(10) NOT NULL COMMENT '如：txt，png，mp3，mp4',
  `size` int(10) NOT NULL COMMENT '单位：Byte',
  `uniq` varchar(36) NOT NULL,
  `create_uid` varchar(36) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `create_time` datetime NOT NULL,
  `update_uid` varchar(36) DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `delete_uid` varchar(36) DEFAULT NULL,
  `delete_time` datetime DEFAULT NULL,
  `is_delete` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`file_id`,`file_path`) USING BTREE,
  UNIQUE KEY `file_id` (`file_id`) USING BTREE,
  UNIQUE KEY `file_path` (`file_path`,`is_delete`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of lxm_file_file
-- ----------------------------
BEGIN;
INSERT INTO `lxm_file_file` VALUES (18, 306, '作品1.lxm', '/Users/lilong/Documents/中科思远/lxm-files/files/staff/总部/技术部/前端岗/lilong/开发文档/AI版/作品1.lxm', 1, 'lxm', 172272, '1bfa42b0-09e8-11ea-b9d4-991f546825f9', '843dc8a0-09df-11ea-9027-b1ebe771fddd', '2019-11-18 17:45:09', NULL, NULL, '843dc8a0-09df-11ea-9027-b1ebe771fddd', '2019-11-19 11:42:39', 0);
INSERT INTO `lxm_file_file` VALUES (19, 305, 'favicon.ico', '/Users/lilong/Documents/中科思远/lxm-files/files/staff/总部/技术部/前端岗/lilong/开发文档/基础版/favicon.ico', 1, 'ico', 4286, '2cc370d0-09e8-11ea-a12a-398b00d7fedd', '843dc8a0-09df-11ea-9027-b1ebe771fddd', '2019-11-18 17:45:37', '843dc8a0-09df-11ea-9027-b1ebe771fddd', '2019-11-19 09:26:27', '843dc8a0-09df-11ea-9027-b1ebe771fddd', '2019-11-19 11:42:39', 0);
INSERT INTO `lxm_file_file` VALUES (20, 307, '矢量智能对象.png', '/Users/lilong/Documents/中科思远/lxm-files/files/staff/总部/技术部/前端岗/lilong/开发文档/官网/矢量智能对象.png', 1, 'png', 7503, '30707340-09e8-11ea-84ae-a5c8382275d2', '843dc8a0-09df-11ea-9027-b1ebe771fddd', '2019-11-18 17:45:43', NULL, NULL, '52adfe30-0a99-11ea-9081-df2084ad8b05', '2019-12-05 15:15:02', 1);
INSERT INTO `lxm_file_file` VALUES (21, 318, '微信截图.png', '/Users/lilong/Documents/中科思远/lxm-files/files/staff/总部/技术部/设计岗/ouyang/重回设计资料/微信截图.png', 1, 'png', 214694, '620e3760-0aa2-11ea-9b24-0d7892dbdfe2', '52adfe30-0a99-11ea-9081-df2084ad8b05', '2019-11-19 15:58:33', '52adfe30-0a99-11ea-9081-df2084ad8b05', '2019-11-19 16:26:54', '52adfe30-0a99-11ea-9081-df2084ad8b05', '2019-11-19 16:09:43', 0);
INSERT INTO `lxm_file_file` VALUES (22, 318, '矢量智能对象.png', '/Users/lilong/Documents/中科思远/lxm-files/files/staff/总部/技术部/设计岗/ouyang/重回设计资料/矢量智能对象.png', 1, 'png', 7503, '70798940-0aab-11ea-be68-9dcabf256196', '52adfe30-0a99-11ea-9081-df2084ad8b05', '2019-11-19 17:03:23', NULL, NULL, NULL, NULL, 0);
INSERT INTO `lxm_file_file` VALUES (24, 318, 'favicon.ico', '/Users/lilong/Documents/中科思远/lxm-files/files/staff/总部/技术部/设计岗/ouyang/重回设计资料/favicon.ico', 1, 'ico', 4286, '9b302310-0aab-11ea-afa4-c14646893c92', '52adfe30-0a99-11ea-9081-df2084ad8b05', '2019-11-19 17:04:34', NULL, NULL, '52adfe30-0a99-11ea-9081-df2084ad8b05', '2019-11-21 20:04:01', 0);
INSERT INTO `lxm_file_file` VALUES (25, 297, 'dot.png', '/Users/lilong/Documents/中科思远/lxm-files/files/staff/总部/技术部/前端岗/lilong/dot.png', 1, 'png', 78, 'eadf7ac0-0b5d-11ea-8578-3b4afb4cd83e', 'b00ac660-09dd-11ea-a6e4-b7d561e1d6d4', '2019-11-20 14:20:58', NULL, NULL, NULL, NULL, 0);
INSERT INTO `lxm_file_file` VALUES (26, 319, '图片1.png', '/Users/lilong/Documents/中科思远/lxm-files/files/staff/总部/技术部/设计岗/ouyang/设计文档/图片1.png', 1, 'png', 13437, '3cf87970-0c52-11ea-9809-21eeecff27d4', '52adfe30-0a99-11ea-9081-df2084ad8b05', '2019-11-21 19:29:53', NULL, NULL, NULL, NULL, 0);
INSERT INTO `lxm_file_file` VALUES (27, 319, '明理求真.cdr', '/Users/lilong/Documents/中科思远/lxm-files/files/staff/总部/技术部/设计岗/ouyang/设计文档/明理求真.cdr', 1, 'cdr', 425892, 'ba85f4e0-1674-11ea-8e36-4bbf119c321f', '52adfe30-0a99-11ea-9081-df2084ad8b05', '2019-12-04 17:01:58', NULL, NULL, NULL, NULL, 0);
INSERT INTO `lxm_file_file` VALUES (28, 319, '关闭按钮.png', '/Users/lilong/Documents/中科思远/lxm-files/files/staff/总部/技术部/设计岗/ouyang/设计文档/关闭按钮.png', 1, 'png', 229, '98efd2a0-1675-11ea-a523-6f9d3b0ccc6d', '52adfe30-0a99-11ea-9081-df2084ad8b05', '2019-12-04 17:08:12', NULL, NULL, NULL, NULL, 0);
INSERT INTO `lxm_file_file` VALUES (29, 317, '明理求真111.cdr', '/Users/lilong/Documents/中科思远/lxm-files/files/staff/总部/技术部/设计岗/ouyang/明理求真111.cdr', 1, 'cdr', 425892, '6eef5fd0-172d-11ea-9b4f-458cd0737fe4', '52adfe30-0a99-11ea-9081-df2084ad8b05', '2019-12-05 15:04:09', '52adfe30-0a99-11ea-9081-df2084ad8b05', '2019-12-05 15:52:33', NULL, NULL, 0);
INSERT INTO `lxm_file_file` VALUES (30, 317, '关闭按钮.png', '/Users/lilong/Documents/中科思远/lxm-files/files/staff/总部/技术部/设计岗/ouyang/关闭按钮.png', 1, 'png', 229, '2ff521b0-172e-11ea-8c10-d7e26d27cb9b', '52adfe30-0a99-11ea-9081-df2084ad8b05', '2019-12-05 15:09:32', NULL, NULL, '52adfe30-0a99-11ea-9081-df2084ad8b05', '2019-12-05 15:13:51', 1);
INSERT INTO `lxm_file_file` VALUES (31, 317, '合阳中学.plt', '/Users/lilong/Documents/中科思远/lxm-files/files/staff/总部/技术部/设计岗/ouyang/合阳中学.plt', 1, 'plt', 6240, '4a347df0-172e-11ea-af0a-fbfc328b4ee5', '52adfe30-0a99-11ea-9081-df2084ad8b05', '2019-12-05 15:10:16', NULL, NULL, NULL, NULL, 0);
INSERT INTO `lxm_file_file` VALUES (32, 317, '抽奖.psd', '/Users/lilong/Documents/中科思远/lxm-files/files/staff/总部/技术部/设计岗/ouyang/抽奖.psd', 1, 'psd', 4737666, '5c0f1c10-172e-11ea-92e4-db97165a212d', '52adfe30-0a99-11ea-9081-df2084ad8b05', '2019-12-05 15:10:46', NULL, NULL, NULL, NULL, 0);
COMMIT;

-- ----------------------------
-- Table structure for lxm_file_share
-- ----------------------------
DROP TABLE IF EXISTS `lxm_file_share`;
CREATE TABLE `lxm_file_share` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` varchar(36) NOT NULL,
  `file_id` int(10) DEFAULT NULL COMMENT '如果分享的是目录，文件ID可以为空',
  `dir_id` int(10) DEFAULT NULL COMMENT '如果分享的是文件，目录ID可以为空',
  `with_uid` varchar(36) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `with_job_id` int(10) DEFAULT NULL,
  `with_dep_id` int(10) DEFAULT NULL,
  `perms_upload` int(1) NOT NULL DEFAULT '0',
  `perms_download` int(1) NOT NULL DEFAULT '0',
  `perms_update` int(1) NOT NULL DEFAULT '0',
  `perms_delete` int(1) NOT NULL DEFAULT '0',
  `is_delete` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of lxm_file_share
-- ----------------------------
BEGIN;
INSERT INTO `lxm_file_share` VALUES (26, '8e2cbb20-09dd-11ea-a6e4-b7d561e1d6d4', NULL, 277, 'b00ac660-09dd-11ea-a6e4-b7d561e1d6d4', NULL, NULL, 1, 1, 1, 1, 0);
INSERT INTO `lxm_file_share` VALUES (27, '8e2cbb20-09dd-11ea-a6e4-b7d561e1d6d4', NULL, 279, 'b00ac660-09dd-11ea-a6e4-b7d561e1d6d4', NULL, NULL, 1, 1, 1, 1, 0);
INSERT INTO `lxm_file_share` VALUES (28, '8e2cbb20-09dd-11ea-a6e4-b7d561e1d6d4', 20, NULL, 'b00ac660-09dd-11ea-a6e4-b7d561e1d6d4', NULL, NULL, 1, 1, 1, 0, 0);
INSERT INTO `lxm_file_share` VALUES (29, '8e2cbb20-09dd-11ea-a6e4-b7d561e1d6d4', NULL, 308, '843dc8a0-09df-11ea-9027-b1ebe771fddd', NULL, NULL, 1, 1, 1, 0, 0);
INSERT INTO `lxm_file_share` VALUES (30, '843dc8a0-09df-11ea-9027-b1ebe771fddd', NULL, 305, NULL, NULL, 214, 1, 1, 1, 0, 0);
INSERT INTO `lxm_file_share` VALUES (32, '52adfe30-0a99-11ea-9081-df2084ad8b05', NULL, 307, '52adfe30-0a99-11ea-9081-df2084ad8b05', NULL, NULL, 1, 1, 1, 1, 0);
COMMIT;

-- ----------------------------
-- Table structure for lxm_user_common
-- ----------------------------
DROP TABLE IF EXISTS `lxm_user_common`;
CREATE TABLE `lxm_user_common` (
  `uid` varchar(36) NOT NULL COMMENT '为了和其他用户表区分，使用uuid',
  `username` varchar(50) NOT NULL COMMENT '不能和其他用户表的username重复，这里使用邮箱',
  `password` varchar(60) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `homefolder` varchar(1000) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `create_time` datetime NOT NULL,
  `last_pass_change` datetime DEFAULT NULL,
  `last_login_time` datetime DEFAULT NULL,
  `last_logout_time` datetime DEFAULT NULL,
  `delete_uid` varchar(36) DEFAULT NULL,
  `delete_time` datetime DEFAULT NULL,
  `is_delete` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`uid`,`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of lxm_user_common
-- ----------------------------
BEGIN;
INSERT INTO `lxm_user_common` VALUES ('67f20320-09f6-11ea-abdf-db33cb080f93', 'guest', '$2b$10$oGV.fvrEY.mE8jkUpOh85uW2dqdsMVdpETe3EIFnZ0QKTSpoCBdCy', '/Users/lilong/Documents/中科思远/lxm-files/files/common/guest', '2019-11-18 19:27:29', NULL, NULL, NULL, NULL, NULL, 0);
COMMIT;

-- ----------------------------
-- Table structure for lxm_user_department
-- ----------------------------
DROP TABLE IF EXISTS `lxm_user_department`;
CREATE TABLE `lxm_user_department` (
  `dep_id` int(10) NOT NULL AUTO_INCREMENT,
  `dep_name` varchar(255) NOT NULL,
  `dep_dir` varchar(1000) NOT NULL,
  `par_id` int(10) NOT NULL DEFAULT '0',
  `type` int(1) NOT NULL COMMENT '类型：1，2',
  `address` varchar(100) DEFAULT NULL,
  `create_uid` varchar(36) NOT NULL,
  `create_time` datetime NOT NULL,
  `update_uid` varchar(36) DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `delete_uid` varchar(36) DEFAULT NULL,
  `delete_time` datetime DEFAULT NULL,
  `is_delete` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`dep_id`,`dep_dir`),
  UNIQUE KEY `dep_dir` (`dep_dir`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=216 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of lxm_user_department
-- ----------------------------
BEGIN;
INSERT INTO `lxm_user_department` VALUES (210, '总部', '/Users/lilong/Documents/中科思远/lxm-files/files/staff/总部', 0, 1, '', '85643570-05e8-11ea-b251-bf127ba383f1', '2019-11-18 15:47:53', NULL, NULL, NULL, NULL, 0);
INSERT INTO `lxm_user_department` VALUES (211, '学校', '/Users/lilong/Documents/中科思远/lxm-files/files/staff/学校', 0, 2, '', '85643570-05e8-11ea-b251-bf127ba383f1', '2019-11-18 15:49:11', NULL, NULL, NULL, NULL, 0);
INSERT INTO `lxm_user_department` VALUES (213, '技术部', '/Users/lilong/Documents/中科思远/lxm-files/files/staff/总部/技术部', 210, 1, '', '85643570-05e8-11ea-b251-bf127ba383f1', '2019-11-18 15:50:11', NULL, NULL, NULL, NULL, 0);
INSERT INTO `lxm_user_department` VALUES (214, '销售部', '/Users/lilong/Documents/中科思远/lxm-files/files/staff/总部/销售部', 210, 1, '', '85643570-05e8-11ea-b251-bf127ba383f1', '2019-11-18 15:50:20', NULL, NULL, NULL, NULL, 0);
INSERT INTO `lxm_user_department` VALUES (215, '校区A', '/Users/lilong/Documents/中科思远/lxm-files/files/staff/学校/校区A', 211, 1, '', '843dc8a0-09df-11ea-9027-b1ebe771fddd', '2019-11-26 11:14:07', NULL, NULL, NULL, NULL, 0);
COMMIT;

-- ----------------------------
-- Table structure for lxm_user_job
-- ----------------------------
DROP TABLE IF EXISTS `lxm_user_job`;
CREATE TABLE `lxm_user_job` (
  `job_id` int(10) NOT NULL AUTO_INCREMENT,
  `job_name` varchar(255) NOT NULL,
  `job_dir` varchar(1000) NOT NULL,
  `dep_id` int(10) NOT NULL COMMENT '对应部门ID',
  `create_uid` varchar(36) NOT NULL,
  `create_time` datetime NOT NULL,
  `update_uid` varchar(36) DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `delete_uid` varchar(36) DEFAULT NULL,
  `delete_time` datetime DEFAULT NULL,
  `is_delete` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`job_id`,`job_dir`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of lxm_user_job
-- ----------------------------
BEGIN;
INSERT INTO `lxm_user_job` VALUES (9, '总经理岗', '/Users/lilong/Documents/中科思远/lxm-files/files/staff/总部/总经理岗', 210, '85643570-05e8-11ea-b251-bf127ba383f1', '2019-11-18 15:51:00', NULL, NULL, NULL, NULL, 0);
INSERT INTO `lxm_user_job` VALUES (10, '技术经理岗', '/Users/lilong/Documents/中科思远/lxm-files/files/staff/总部/技术部/技术经理岗', 213, '85643570-05e8-11ea-b251-bf127ba383f1', '2019-11-18 15:51:11', NULL, NULL, NULL, NULL, 0);
INSERT INTO `lxm_user_job` VALUES (11, '前端岗', '/Users/lilong/Documents/中科思远/lxm-files/files/staff/总部/技术部/前端岗', 213, '85643570-05e8-11ea-b251-bf127ba383f1', '2019-11-18 15:51:18', NULL, NULL, NULL, NULL, 0);
INSERT INTO `lxm_user_job` VALUES (12, '后端岗', '/Users/lilong/Documents/中科思远/lxm-files/files/staff/总部/技术部/后端岗', 213, '85643570-05e8-11ea-b251-bf127ba383f1', '2019-11-18 15:51:22', NULL, NULL, NULL, NULL, 0);
INSERT INTO `lxm_user_job` VALUES (13, '销售经理岗', '/Users/lilong/Documents/中科思远/lxm-files/files/staff/总部/销售部/销售经理岗', 214, '85643570-05e8-11ea-b251-bf127ba383f1', '2019-11-18 15:51:36', NULL, NULL, NULL, NULL, 0);
INSERT INTO `lxm_user_job` VALUES (14, '售前岗', '/Users/lilong/Documents/中科思远/lxm-files/files/staff/总部/销售部/售前岗', 214, '85643570-05e8-11ea-b251-bf127ba383f1', '2019-11-18 15:51:46', NULL, NULL, NULL, NULL, 0);
INSERT INTO `lxm_user_job` VALUES (15, '售后岗', '/Users/lilong/Documents/中科思远/lxm-files/files/staff/总部/销售部/售后岗', 214, '85643570-05e8-11ea-b251-bf127ba383f1', '2019-11-18 15:51:53', NULL, NULL, NULL, NULL, 0);
INSERT INTO `lxm_user_job` VALUES (20, '设计岗', '/Users/lilong/Documents/中科思远/lxm-files/files/staff/总部/技术部/设计岗', 213, '8e2cbb20-09dd-11ea-a6e4-b7d561e1d6d4', '2019-11-19 14:47:40', NULL, NULL, NULL, NULL, 0);
INSERT INTO `lxm_user_job` VALUES (21, '校长岗', '/Users/lilong/Documents/中科思远/lxm-files/files/staff/学校/校区A/校长岗', 215, '843dc8a0-09df-11ea-9027-b1ebe771fddd', '2019-11-26 11:31:02', NULL, NULL, NULL, NULL, 0);
INSERT INTO `lxm_user_job` VALUES (22, '副校长岗', '/Users/lilong/Documents/中科思远/lxm-files/files/staff/学校/校区A/副校长岗', 215, '843dc8a0-09df-11ea-9027-b1ebe771fddd', '2019-11-27 16:10:32', NULL, NULL, NULL, NULL, 0);
COMMIT;

-- ----------------------------
-- Table structure for lxm_user_permission
-- ----------------------------
DROP TABLE IF EXISTS `lxm_user_permission`;
CREATE TABLE `lxm_user_permission` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `job_id` int(10) NOT NULL,
  `create_user` int(1) NOT NULL DEFAULT '0',
  `modify_userinfo` int(1) NOT NULL DEFAULT '0',
  `modify_password` int(1) NOT NULL DEFAULT '0',
  `create_dir` int(1) NOT NULL DEFAULT '0',
  `upload_file` int(1) NOT NULL DEFAULT '0',
  `download_file` int(1) NOT NULL DEFAULT '0',
  `delete_file` int(1) NOT NULL DEFAULT '0',
  `delete_dir` int(1) NOT NULL DEFAULT '0',
  `rename_file` int(1) NOT NULL DEFAULT '0',
  `rename_dir` int(1) NOT NULL DEFAULT '0',
  `target_uid` varchar(36) DEFAULT NULL,
  `target_job_id` int(10) DEFAULT NULL,
  `target_dep_id` int(10) DEFAULT NULL,
  `target_user_field` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of lxm_user_permission
-- ----------------------------
BEGIN;
INSERT INTO `lxm_user_permission` VALUES (1, 20, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, NULL, NULL, NULL, NULL);
INSERT INTO `lxm_user_permission` VALUES (3, 21, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL);
INSERT INTO `lxm_user_permission` VALUES (4, 22, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, NULL, NULL, NULL, NULL);
COMMIT;

-- ----------------------------
-- Table structure for lxm_user_staff
-- ----------------------------
DROP TABLE IF EXISTS `lxm_user_staff`;
CREATE TABLE `lxm_user_staff` (
  `uid` varchar(36) NOT NULL COMMENT '不能和其他用户表重复，使用uuid生成',
  `username` varchar(50) NOT NULL COMMENT '不能和其他用户表重复',
  `password` varchar(60) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `homefolder` varchar(1000) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `dep_id` int(10) NOT NULL,
  `job_id` int(10) NOT NULL,
  `job_number` int(10) NOT NULL COMMENT '工号',
  `phone_number` varchar(11) NOT NULL,
  `true_name` varchar(20) NOT NULL,
  `nick_name` varchar(30) NOT NULL,
  `gender` int(1) NOT NULL DEFAULT '1' COMMENT '1：男，2：女',
  `age` int(3) DEFAULT NULL,
  `ID_card` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `birth_date` date DEFAULT NULL,
  `bank_account` int(20) DEFAULT NULL,
  `employ_type` int(1) DEFAULT NULL COMMENT '在职类型',
  `address` varchar(100) DEFAULT NULL,
  `grade` int(1) DEFAULT NULL COMMENT '级别',
  `direct_leader_id` int(10) DEFAULT NULL COMMENT '直属领导ID',
  `is_official_employ` int(1) DEFAULT NULL COMMENT '是否正式员工，1：是，2：否',
  `join_date` datetime DEFAULT NULL COMMENT '入职时间',
  `turn_official_date` datetime DEFAULT NULL COMMENT '转正时间',
  `memo` varchar(255) DEFAULT NULL COMMENT '备注',
  `last_pass_change` datetime DEFAULT NULL,
  `last_login_time` datetime DEFAULT NULL,
  `last_logout_time` datetime DEFAULT NULL,
  `create_uid` varchar(36) NOT NULL,
  `create_time` datetime NOT NULL,
  `update_uid` varchar(36) DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `delete_uid` varchar(10) DEFAULT NULL,
  `delete_time` datetime DEFAULT NULL,
  `is_delete` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`uid`,`username`),
  UNIQUE KEY `username` (`username`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of lxm_user_staff
-- ----------------------------
BEGIN;
INSERT INTO `lxm_user_staff` VALUES ('03c778f0-09e0-11ea-85c4-17bb4b079cf8', 'panpeng', '$2b$10$Px0iaj3V2SmrLqX9LInDWOYMGZ9hxsoLTtNuCxkH2MYPHByxDfV3.', '/Users/lilong/Documents/中科思远/lxm-files/files/staff/总部/销售部/售前岗/panpeng', 214, 14, 6, '18888888886', '潘鹏', '', 1, NULL, '5019219910426221X', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2019-11-19 17:36:50', NULL, '8e2cbb20-09dd-11ea-a6e4-b7d561e1d6d4', '2019-11-18 16:47:12', NULL, NULL, NULL, NULL, 0);
INSERT INTO `lxm_user_staff` VALUES ('0f921e60-09e0-11ea-b6fd-57a9a9a40913', 'tangwen', '$2b$10$E79uzLSqvBuHJxNvtF3AfeQPz3cam.8znb103pjyY4WSL5pmkprVu', '/Users/lilong/Documents/中科思远/lxm-files/files/staff/总部/销售部/售后岗/tangwen', 214, 15, 7, '18888888887', '唐文', '', 1, NULL, '5019219910426221X', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '8e2cbb20-09dd-11ea-a6e4-b7d561e1d6d4', '2019-11-18 16:47:32', NULL, NULL, NULL, NULL, 0);
INSERT INTO `lxm_user_staff` VALUES ('394a6be0-0aad-11ea-b804-41c5346fba10', 'chengyuxi', '$2b$10$oTAcacSToVLG7WJld1mlWegAVoFQVunkkmwL6BXiczVlxUmNucuxu', '/Users/lilong/Documents/中科思远/lxm-files/files/staff/总部/技术部/设计岗/chengyuxi', 213, 20, 9, '18888888889', '陈羽熙', '', 1, NULL, '5019219910426221X', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '52adfe30-0a99-11ea-9081-df2084ad8b05', '2019-11-19 17:16:09', NULL, NULL, NULL, NULL, 0);
INSERT INTO `lxm_user_staff` VALUES ('52adfe30-0a99-11ea-9081-df2084ad8b05', 'ouyang', '$2b$10$qh.dgL6QDJjUC4JEE0.7.O6vQQN5a8vcU0qF7crbyzaYT7NaC53xO', '/Users/lilong/Documents/中科思远/lxm-files/files/staff/总部/技术部/设计岗/ouyang', 213, 20, 8, '18888888888', '欧洋', '', 1, NULL, '5019219910426221X', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2019-12-05 16:36:26', NULL, '8e2cbb20-09dd-11ea-a6e4-b7d561e1d6d4', '2019-11-19 14:53:42', NULL, NULL, NULL, NULL, 0);
INSERT INTO `lxm_user_staff` VALUES ('7a97d7f0-09df-11ea-9bfc-7d0d6041a49e', 'litingqiang', '$2b$10$L5ktA3SDkOdBnyIeO0droeBo1S7OaxzuOBbuc1VFUgQfg2zhmlc8m', '/Users/lilong/Documents/中科思远/lxm-files/files/staff/总部/技术部/技术经理岗/litingqiang', 213, 10, 2, '18888888882', '李廷强', '', 1, NULL, '5019219910426221X', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '8e2cbb20-09dd-11ea-a6e4-b7d561e1d6d4', '2019-11-18 16:43:22', NULL, NULL, NULL, NULL, 0);
INSERT INTO `lxm_user_staff` VALUES ('843dc8a0-09df-11ea-9027-b1ebe771fddd', 'lilong', '$2b$10$tLaJzeYol.U.zXR4fMvfwOQlm/qGjKb8cNtHGVfssnP6gS6eREZpy', '/Users/lilong/Documents/中科思远/lxm-files/files/staff/总部/技术部/前端岗/lilong', 213, 11, 3, '18888888883', '李龙', '', 1, NULL, '5019219910426221X', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2019-12-05 16:29:24', NULL, '8e2cbb20-09dd-11ea-a6e4-b7d561e1d6d4', '2019-11-18 16:43:38', NULL, NULL, NULL, NULL, 0);
INSERT INTO `lxm_user_staff` VALUES ('8e2cbb20-09dd-11ea-a6e4-b7d561e1d6d4', 'lexuemao', '$2b$10$SIS.P8sK9hPl7AFNrAyecORcRia3hRZVn.HVtugJWjlsk.XPoTYT6', '/Users/lilong/Documents/中科思远/lxm-files/files', 0, 0, 1, '16666666666', '超级管理员', '乐学猫', 1, 18, '50192119990909999X', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2019-11-19 14:42:53', NULL, '0', '2019-11-18 16:29:36', NULL, NULL, NULL, NULL, 0);
INSERT INTO `lxm_user_staff` VALUES ('8f26c0a0-09df-11ea-8989-8b09e81ea253', 'liuweiming', '$2b$10$4T8CL1J14Q07Hj/zgto7O.3kCcY/IKwv9BPNVCtygsbm8APT9AA8a', '/Users/lilong/Documents/中科思远/lxm-files/files/staff/总部/技术部/后端岗/liuweiming', 213, 12, 4, '18888888884', '刘卫民', '', 1, NULL, '5019219910426221X', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2019-11-19 17:41:16', NULL, '8e2cbb20-09dd-11ea-a6e4-b7d561e1d6d4', '2019-11-18 16:43:57', NULL, NULL, NULL, NULL, 0);
INSERT INTO `lxm_user_staff` VALUES ('930c4bf0-10f5-11ea-be6e-0b7972178198', 'mengran', '$2b$10$6wijo1gjPxhBkEQhH9BQZexOQx.A/McZtnQQ.tcxYFIdwjF12JKvG', '/Users/lilong/Documents/中科思远/lxm-files/files/staff/学校/校区A/副校长岗/mengran', 215, 22, 119, '18888888888', '孟然', '孟老师', 1, NULL, '50190119910101119X', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '52adfe30-0a99-11ea-9081-df2084ad8b05', '2019-11-27 17:09:10', NULL, NULL, NULL, NULL, 0);
INSERT INTO `lxm_user_staff` VALUES ('b00ac660-09dd-11ea-a6e4-b7d561e1d6d4', 'zhouping', '$2b$10$Lj2.xXEdXL2SsRSQCvZz9Oen44HkB8bHhsHEZIGO3x2QndoGZjGeG', '/Users/lilong/Documents/中科思远/lxm-files/files/staff/总部/总经理岗/zhouping', 210, 9, 1, '18888888881', '周平', '', 1, NULL, '5019219910426221X', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2019-12-05 18:37:20', NULL, '8e2cbb20-09dd-11ea-a6e4-b7d561e1d6d4', '2019-11-18 16:30:33', NULL, NULL, NULL, NULL, 0);
INSERT INTO `lxm_user_staff` VALUES ('f5fae900-09df-11ea-822c-03ae4be5ecb3', 'zhouyuan', '$2b$10$0Uhpb3FNZaMXNFwoC6yfbOSz02RvbZaKbgqy7KluprEZ/S6TOQ4hu', '/Users/lilong/Documents/中科思远/lxm-files/files/staff/总部/销售部/销售经理岗/zhouyuan', 214, 13, 5, '18888888885', '周媛', '', 1, NULL, '5019219910426221X', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '8e2cbb20-09dd-11ea-a6e4-b7d561e1d6d4', '2019-11-18 16:46:49', NULL, NULL, NULL, NULL, 0);
COMMIT;

SET FOREIGN_KEY_CHECKS = 1;
